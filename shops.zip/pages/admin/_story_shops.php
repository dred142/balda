<center><b><span class="h-ferm">������� ��������</span></b></center><br />
<?PHP
$tdadd = time() - 5*60;
	if(isset($_POST["clean"])){
	
		$db->Query("DELETE FROM db_stats_shops WHERE date_add < '$tdadd'");
		echo "<center><font color = 'green'><b>�������!</b></font></center><BR />";
	}



$db->Query("SELECT db_users_a.user, db_users_a.date_reg, db_users_a.font,  db_users_a.ur, db_users_a.pol, db_stats_shops.user, db_stats_shops.tree_name, db_stats_shops.amounte, db_stats_shops.date_add, db_stats_shops.amount, db_stats_shops.id FROM db_users_a, db_stats_shops 
  WHERE db_users_a.id = db_stats_shops.user_id ORDER BY id DESC");
if($db->NumRows() > 0){

?>
<table class="uTable" align="center" width="100%"><tr>
    <td align="center" width="50" class="m-tb">ID</td>
    <td align="center" class="m-tb">�����</td>
    <td align="center" width="75" class="m-tb">��������</td>
	<td align="center" width="75" class="m-tb">���������</td>
	<td align="center" width="75" class="m-tb">������ [��.]</td>
	<td align="center" width="150" class="m-tb">����</td>
  </tr>


<?PHP

	while($data = $db->FetchArray()){
	
	?>
	<tr>
    <td align="center" width="50"><?=$data["id"]; ?></td>
    <td align="center"><?=$data['pol']; ?> <font color="<?=$data["font"]; ?>"><?=$data["user"]; ?></font><?
		$reit=intval($data["ur"]);
		
		if ($reit >= 0 and  $reit < 1000 ) { echo '<b><img src="/images/r1.png" style="width:16px;" class="icon"></b>';}
		elseif ($reit >= 1000 and  $reit < 3000 ){ echo '<b><img src="/images/r2.png" style="width:16px;" class="icon"></b>';}
		elseif ($reit >= 3000 and  $reit < 5000 ){ echo '<b><img src="/images/r3.png" style="width:16px;" class="icon"></b>';}
		elseif ($reit >= 5000 and  $reit < 8000 ){ echo '<b><img src="/images/r4.png" style="width:16px;" class="icon"></b>';}
		elseif ($reit >= 8000 and  $reit < 999999999 ){ echo '<b><img src="/images/r5.png" style="width:16px;" class="icon"></b>';}?></td>
    <td align="center" width="75"><?=$data["tree_name"]; ?></td>
	<td align="center" width="75"><?=$data["amount"]; ?> <img src="/images/rub.png" style="width:16px;" class="icon"></td>
	<td align="center" width="75"><?=$data["amounte"]; ?></td>
	<td align="center" width="150"><img src="/images/calendar.png" style="width:16px;" class="icon"> <?=date("d.m.Y H:i",$data["date_add"]); ?></td>
  	</tr>
	<?PHP
	
	}

?>

</table>
<BR />
<form action="" method="post">
<center><input type="submit" name="clean" value="��������" /></center>
</form>
<?PHP

}else echo "<center><b>������� ���</b></center><BR />";
?>
